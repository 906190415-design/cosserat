function [outputArg1,outputArg2] = untitled(inputArg1,inputArg2)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

